const express = require('express');
const cors = require('cors');
const path = require('path');
const session = require('express-session');
const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
const config = require('./config.json');

// --- Config (from config.json) ---
const OBFUSCATE_API_KEY = 'obf_6d296fc8_lUNchQB3YCU1v56RJdExeKlXwjGCoPxT';
const DISCORD_CLIENT_ID = '1535363975871733891';
const DISCORD_CLIENT_SECRET = 'EB2qN1-26awhTHKy1iMoRCVOiMEbho-3';
const DISCORD_REDIRECT_URI = 'http://localhost:3000/auth/discord/callback';
const SESSION_SECRET = 'super_secret_session_key';
const DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/1535372902424121367/KemvVqgqryxTLMWCQc6P1UZA67UGOE-3WTlnEl9t6mIymOIejccuZ9lGTp-FF7MuPK98';
const ADMIN_IDS = ["1001882482846736414", "1405284521166770347"];
const DISCORD_SERVER_INVITE = 'https://discord.gg/UHcQhtpyTF'; // <--- ضع رابط الديسكورد هنا
const PORT = 3000;

// Try loading better-sqlite3
let db;
try {
    const Database = require('better-sqlite3');
    db = new Database('database.sqlite');

    // Initialize Tables
    db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT,
            password TEXT,
            api_key TEXT,
            plan TEXT DEFAULT 'Free',
            is_banned INTEGER DEFAULT 0,
            watermark TEXT,
            webhook_url TEXT,
            avatar TEXT
        );
        CREATE TABLE IF NOT EXISTS history (
            id TEXT PRIMARY KEY,
            user_id TEXT,
            script_name TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS stats (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            total_obfuscations INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS promo_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE,
            plan TEXT,
            is_used INTEGER DEFAULT 0,
            used_by TEXT
        );
        INSERT OR IGNORE INTO stats (id, total_obfuscations) VALUES (1, 0);
    `);

    // Migrations
    try { db.exec('ALTER TABLE users ADD COLUMN password TEXT'); } catch(e) {}
    try { db.exec("ALTER TABLE users ADD COLUMN plan TEXT DEFAULT 'Free'"); } catch(e) {}
    try { db.exec('ALTER TABLE users ADD COLUMN watermark TEXT'); } catch(e) {}
    try { db.exec('ALTER TABLE users ADD COLUMN webhook_url TEXT'); } catch(e) {}
    try { db.exec('ALTER TABLE users ADD COLUMN avatar TEXT'); } catch(e) {}
    // Migrate promo_codes to have id column
    try {
        const hasId = db.prepare("PRAGMA table_info(promo_codes)").all().some(c => c.name === 'id');
        if (!hasId) {
            db.exec(`
                ALTER TABLE promo_codes RENAME TO promo_codes_old;
                CREATE TABLE promo_codes (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, plan TEXT, is_used INTEGER DEFAULT 0, used_by TEXT);
                INSERT INTO promo_codes (code, plan, is_used, used_by) SELECT code, plan, is_used, used_by FROM promo_codes_old;
                DROP TABLE promo_codes_old;
            `);
        }
    } catch(e) {}

    console.log('✅ Database connected');
} catch (error) {
    console.error('❌ Database error: Please run `npm install better-sqlite3 uuid`');
}

function hashPassword(password) { return crypto.createHash('sha256').update(password).digest('hex'); }

// --- Express Setup ---
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({ secret: SESSION_SECRET, resave: false, saveUninitialized: false, cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 } }));

// --- Authentication ---
app.post('/api/auth/register', (req, res) => {
    if (!db) return res.status(500).json({ error: 'DB not ready' });
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Missing fields' });

    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    if (existing) return res.status(400).json({ error: 'Username already taken' });

    const id = uuidv4();
    db.prepare('INSERT INTO users (id, username, password) VALUES (?, ?, ?)').run(id, username, hashPassword(password));
    req.session.user = { id, username };
    res.json({ success: true });
});

app.post('/api/auth/login', (req, res) => {
    if (!db) return res.status(500).json({ error: 'DB not ready' });
    const { username, password } = req.body;
    const userRow = db.prepare('SELECT * FROM users WHERE username = ? AND password = ?').get(username, hashPassword(password));
    if (!userRow) return res.status(401).json({ error: 'Invalid credentials' });
    if (userRow.is_banned) return res.status(403).json({ error: 'Account banned' });
    req.session.user = { id: userRow.id, username: userRow.username };
    res.json({ success: true });
});

app.get('/auth/discord', (req, res) => { res.redirect(`https://discord.com/api/oauth2/authorize?client_id=${DISCORD_CLIENT_ID}&redirect_uri=${encodeURIComponent(DISCORD_REDIRECT_URI)}&response_type=code&scope=identify`); });
app.get('/auth/discord/callback', async (req, res) => {
    const code = req.query.code;
    if (!code) return res.redirect('/login.html');
    try {
        const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
            method: 'POST',
            body: new URLSearchParams({ client_id: DISCORD_CLIENT_ID, client_secret: DISCORD_CLIENT_SECRET, code, grant_type: 'authorization_code', redirect_uri: DISCORD_REDIRECT_URI, scope: 'identify' }),
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
        const tokenData = await tokenRes.json();
        console.log('Token Data:', tokenData);
        const userRes = await fetch('https://discord.com/api/users/@me', { headers: { authorization: `Bearer ${tokenData.access_token}` } });
        const user = await userRes.json();
        console.log('User Data:', user);

        if (db) {
            db.prepare('INSERT INTO users (id, username, avatar) VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET username = excluded.username, avatar = excluded.avatar').run(user.id, user.username, user.avatar || null);
            const userRow = db.prepare('SELECT is_banned FROM users WHERE id = ?').get(user.id);
            if (userRow && userRow.is_banned === 1) return res.status(403).send('Banned.');
        }
        req.session.user = user;
        res.redirect('/dashboard');
    } catch (e) {
        console.error(e);
        res.redirect('/login.html?error=auth_failed');
    }
});

app.get('/auth/logout', (req, res) => { req.session.destroy(); res.redirect('/login.html'); });

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'landing.html'));
});

app.get('/api/live-feed', (req, res) => {
    if (!db) return res.json([]);
    try {
        const feed = db.prepare('SELECT h.created_at, u.username, u.avatar, u.id as user_id FROM history h JOIN users u ON h.user_id = u.id ORDER BY h.created_at DESC LIMIT 5').all();
        res.json(feed);
    } catch(e) { res.json([]); }
});

app.get('/dashboard', (req, res) => {
    if (!req.session.user) return res.redirect('/login.html');
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Demo Obfuscate (Public)
app.get('/join-discord', (req, res) => res.redirect(DISCORD_SERVER_INVITE));

app.post('/api/demo-obfuscate', async (req, res) => {
    const { source } = req.body;
    if (!source || source.length > 500) return res.status(400).json({ error: 'Demo limit exceeded (max 500 chars).' });

    try {
        const response = await fetch('https://api.obfuscate.club/v1/obfuscate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${OBFUSCATE_API_KEY}` },
            body: JSON.stringify({ source, target: 'lua54' })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || 'API Error');
        res.json({ output: data.output || data.code || data.result || data.script });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// --- User API ---
app.get('/api/user', (req, res) => {
    if (!req.session.user) return res.status(401).json({ error: 'Unauthorized' });
    if (db) {
        const row = db.prepare('SELECT plan, is_banned, watermark, webhook_url FROM users WHERE id = ?').get(req.session.user.id);
        if (row) {
            if (row.is_banned) return res.status(403).json({ error: 'Banned' });
            Object.assign(req.session.user, { plan: row.plan || 'Free', watermark: row.watermark, webhook_url: row.webhook_url });
        }
    }
    req.session.user.is_admin = ADMIN_IDS.includes(req.session.user.id);
    res.json(req.session.user);
});

app.post('/api/user/settings', (req, res) => {
    if (!req.session.user) return res.status(401).json({ error: 'Unauthorized' });
    if (!db) return res.status(500).json({ error: 'DB not ready' });
    const row = db.prepare('SELECT plan FROM users WHERE id = ?').get(req.session.user.id);
    if (row.plan !== 'Premium' && !ADMIN_IDS.includes(req.session.user.id)) return res.status(403).json({ error: 'Premium feature' });

    const { watermark, webhook_url } = req.body;
    db.prepare('UPDATE users SET watermark = ?, webhook_url = ? WHERE id = ?').run(watermark || null, webhook_url || null, req.session.user.id);
    res.json({ success: true });
});

app.get('/api/history', (req, res) => {
    if (!req.session.user) return res.status(401).json({ error: 'Unauthorized' });
    if (!db) return res.json([]);
    res.json(db.prepare('SELECT * FROM history WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(req.session.user.id));
});

app.post('/api/redeem-code', (req, res) => {
    if (!req.session.user) return res.status(401).json({ error: 'Unauthorized' });
    if (!db) return res.status(500).json({ error: 'DB error' });
    const { code } = req.body;
    const codeRow = db.prepare('SELECT * FROM promo_codes WHERE code = ?').get(code);
    if (!codeRow) return res.status(400).json({ error: 'Invalid code.' });
    if (codeRow.is_used) return res.status(400).json({ error: 'Code already used.' });
    db.prepare('UPDATE promo_codes SET is_used = 1, used_by = ? WHERE code = ?').run(req.session.user.id, code);
    db.prepare('UPDATE users SET plan = ? WHERE id = ?').run(codeRow.plan, req.session.user.id);
    res.json({ success: true, plan: codeRow.plan });
});

// --- Admin API ---
function adminAuth(req, res, next) {
    if (!req.session.user || !ADMIN_IDS.includes(req.session.user.id)) return res.status(403).json({ error: 'Admin access required' });
    next();
}

app.get('/api/admin/users', adminAuth, (req, res) => { res.json(db ? db.prepare('SELECT id, username, plan, is_banned FROM users').all() : []); });
app.get('/api/admin/history', adminAuth, (req, res) => {
    res.json(db ? db.prepare(`SELECT h.id, h.script_name, h.created_at, u.username FROM history h LEFT JOIN users u ON h.user_id = u.id ORDER BY h.created_at DESC LIMIT 100`).all() : []);
});
app.get('/api/admin/promo-codes', adminAuth, (req, res) => {
    res.json(db ? db.prepare(`SELECT c.*, u.username as used_by_name FROM promo_codes c LEFT JOIN users u ON c.used_by = u.id ORDER BY c.is_used ASC`).all() : []);
});
app.post('/api/admin/generate-promo', adminAuth, (req, res) => {
    if (!db) return res.status(500).json({ error: 'DB error' });
    const { plan } = req.body;
    if (plan !== 'Basic' && plan !== 'Premium') return res.status(400).json({ error: 'Invalid plan' });
    const code = `OS-${plan.toUpperCase()}-${uuidv4().split('-')[0]}`;
    db.prepare('INSERT INTO promo_codes (code, plan) VALUES (?, ?)').run(code, plan);
    res.json({ success: true, code });
});
app.delete('/api/admin/promo-codes/bulk-delete', adminAuth, (req, res) => {
    if (!db) return res.status(500).json({ error: 'DB error' });
    const { ids } = req.body;
    if (!ids || !Array.isArray(ids)) return res.status(400).json({ error: 'Invalid ids' });
    const placeholders = ids.map(() => '?').join(',');
    db.prepare(`DELETE FROM promo_codes WHERE id IN (${placeholders})`).run(...ids);
    res.json({ success: true, deleted: ids.length });
});
app.delete('/api/admin/promo-codes/:id', adminAuth, (req, res) => {
    if (!db) return res.status(500).json({ error: 'DB error' });
    db.prepare('DELETE FROM promo_codes WHERE id = ?').run(req.params.id);
    res.json({ success: true });
});
app.post('/api/admin/users/:id/toggle-ban', adminAuth, (req, res) => {
    if (!db) return res.status(500).json({ error: 'DB error' });
    const user = db.prepare('SELECT is_banned FROM users WHERE id = ?').get(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    db.prepare('UPDATE users SET is_banned = ? WHERE id = ?').run(user.is_banned ? 0 : 1, req.params.id);
    res.json({ success: true, is_banned: !user.is_banned });
});
app.post('/api/admin/users/:id/revoke-plan', adminAuth, (req, res) => {
    if (!db) return res.status(500).json({ error: 'DB error' });
    const user = db.prepare('SELECT plan FROM users WHERE id = ?').get(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    db.prepare("UPDATE users SET plan = 'Free' WHERE id = ?").run(req.params.id);
    res.json({ success: true });
});
app.get('/api/admin/analytics', adminAuth, (req, res) => {
    if (!db) return res.json({ labels: [], data: [] });
    // SQLite query to get counts for the last 7 days
    const rows = db.prepare(`
        SELECT date(created_at) as date, COUNT(*) as count
        FROM history
        WHERE created_at >= date('now', '-6 days')
        GROUP BY date(created_at)
        ORDER BY date(created_at) ASC
    `).all();

    const labels = [];
    const data = [];
    // Fill missing days
    for(let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const dateStr = d.toISOString().split('T')[0];
        labels.push(dateStr);
        const found = rows.find(r => r.date === dateStr);
        data.push(found ? found.count : 0);
    }
    res.json({ labels, data });
});

// --- Obfuscate Endpoint ---
app.post('/api/obfuscate', async (req, res) => {
    let user = req.session.user;

    if (!user) return res.status(401).json({ error: 'Unauthorized' });

    if (db) {
        const row = db.prepare('SELECT plan, watermark, webhook_url FROM users WHERE id = ?').get(user.id);
        if (row) {
            user.plan = row.plan || 'Free';
            user.watermark = row.watermark;
            user.webhook_url = row.webhook_url;
        }
    }

    if (user.plan === 'Free' && !ADMIN_IDS.includes(user.id)) return res.status(403).json({ error: 'Upgrade required' });

    try {
        const { source, target, options } = req.body;
        if (!source) return res.status(400).json({ error: 'Source code required' });

        const payload = { source, target: target || 'lua54' };

        if (options && Object.keys(options).length > 0) {
            payload.options = {};
            if (options.minify) payload.options.minify = true;
            if ((user.plan === 'Premium' || ADMIN_IDS.includes(user.id))) {
                if (options.antiTamper) payload.options.antiTamper = true;
                if (options.constantEncryption) payload.options.constantEncryption = true;
            }
            if (Object.keys(payload.options).length === 0) delete payload.options;
        }

        const response = await fetch('https://api.obfuscate.club/v1/obfuscate', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${OBFUSCATE_API_KEY}`, 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!response.ok) return res.status(response.status).json({ error: 'API Error', details: await response.text() });

        const data = await response.json();

        // Append Watermark if exists and is premium
        if (user.watermark && (user.plan === 'Premium' || ADMIN_IDS.includes(user.id))) {
            let obfCode = data.output || data.code || data.result || data.obfuscated || data.script;
            if (obfCode) {
                const wm = `-- [[ ${user.watermark} ]] --\n\n`;
                obfCode = wm + obfCode;
                if(data.output) data.output = obfCode;
                else if(data.code) data.code = obfCode;
                else if(data.result) data.result = obfCode;
                else if(data.obfuscated) data.obfuscated = obfCode;
                else if(data.script) data.script = obfCode;
            }
        }

        if (db) {
            db.prepare('UPDATE stats SET total_obfuscations = total_obfuscations + 1 WHERE id = 1').run();
            db.prepare('INSERT INTO history (id, user_id, script_name) VALUES (?, ?, ?)').run(uuidv4(), user.id, 'Build_' + Date.now());
        }

        // Global Admin Webhook (plain HTTP POST — not the Discord bot connection)
        if (DISCORD_WEBHOOK_URL) {
            fetch(DISCORD_WEBHOOK_URL, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ embeds: [{ title: "🛡️ Global Logs: Script Obfuscated", description: `**User:** ${user.username}\n**Target:** ${payload.target}`, color: 0x3b82f6 }] })
            }).catch(()=>{});
        }

        // Personal Webhook
        if (user.webhook_url && (user.plan === 'Premium' || ADMIN_IDS.includes(user.id))) {
            fetch(user.webhook_url, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ embeds: [{ title: "✅ Obfuscation Complete", description: `Your script has been successfully built on Obfuscator Studio.`, color: 0x10b981 }] })
            }).catch(()=>{});
        }

        res.json(data);
    } catch (error) { res.status(500).json({ error: 'Internal Server Error' }); }
});

app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));
