document.addEventListener('DOMContentLoaded', () => {
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Monaco Editors Setup
    let sourceEditor, resultEditor;
    if (document.getElementById('demo-source')) {
        require(['vs/editor/editor.main'], function() {
            monaco.editor.defineTheme('minimalTheme', { base: 'vs-dark', inherit: true, rules: [], colors: { 'editor.background': '#00000000' }});
            monaco.editor.setTheme('minimalTheme');
            
            sourceEditor = monaco.editor.create(document.getElementById('demo-source'), { 
                value: 'local function secret()\n    print("Welcome to iRfx Secure!")\nend\nsecret()', 
                language: 'lua', readOnly: true, minimap: { enabled: false }, automaticLayout: true, fontSize: 13, scrollBeyondLastLine: false 
            });
            
            resultEditor = monaco.editor.create(document.getElementById('demo-result'), { 
                value: '-- Obfuscated output will appear here', 
                language: 'lua', readOnly: true, minimap: { enabled: false }, automaticLayout: true, fontSize: 13, scrollBeyondLastLine: false 
            });
        });
    }

    // Demo Obfuscation Button
    const demoBtn = document.getElementById('demo-run-btn');
    if (demoBtn) {
        demoBtn.addEventListener('click', async () => {
            if (!sourceEditor || demoBtn.disabled) return;
            const source = sourceEditor.getValue().trim();
            if (!source) return;

            // Simple client-side length check to avoid heavy loads
            if (source.length > 500) {
                resultEditor.setValue('-- [ERROR]\n-- Demo script is too long. Please sign up to obfuscate larger scripts.');
                return;
            }

            demoBtn.disabled = true;
            const originalHtml = demoBtn.innerHTML;
            demoBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i> PROCESSING';
            resultEditor.setValue('-- Processing your script...');

            try {
                const response = await fetch('/api/demo-obfuscate', { 
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json' }, 
                    body: JSON.stringify({ source }) 
                });
                const data = await response.json();
                
                if (!response.ok) throw new Error(data.error || 'Failed to obfuscate');
                
                resultEditor.setValue(data.output || data.code || data.result || data.script);
            } catch (error) {
                resultEditor.setValue(`-- [ERROR]\n-- ${error.message}`);
            } finally {
                demoBtn.disabled = false;
                demoBtn.innerHTML = originalHtml;
            }
        });
    }

    // Live Feed
    fetch('/api/live-feed').then(r => r.json()).then(feed => {
        const el = document.getElementById('live-feed');
        if (!el || !feed.length) return;
        el.innerHTML = feed.map(f => {
            const avatar = f.avatar ? `https://cdn.discordapp.com/avatars/${f.user_id}/${f.avatar}.png?size=32` : `https://cdn.discordapp.com/embed/avatars/0.png`;
            const ago = Math.floor((Date.now() - new Date(f.created_at).getTime()) / 60000);
            const time = ago < 1 ? 'just now' : ago < 60 ? ago + 'm ago' : Math.floor(ago/60) + 'h ago';
            return `<div class="feed-item"><img src="${avatar}"><span><strong>${f.username}</strong> obfuscated a script</span><span class="feed-time">${time}</span></div>`;
        }).join('');
    }).catch(() => {});
});
