const Toast = Swal.mixin({ toast: true, position: 'top-end', showConfirmButton: false, timer: 3000, timerProgressBar: true, customClass: { popup: 'custom-swal-popup' } });
const CustomSwal = Swal.mixin({ customClass: { popup: 'custom-swal-popup', title: 'custom-swal-title', confirmButton: 'custom-swal-confirm', cancelButton: 'custom-swal-cancel' }, buttonsStyling: false });

document.addEventListener('DOMContentLoaded', async () => {
    
    // --- LOGIN LOGIC ---
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        let isRegister = false;
        const toggleBtn = document.getElementById('toggle-register');
        const submitBtn = document.getElementById('submit-btn');
        toggleBtn.addEventListener('click', (e) => {
            e.preventDefault(); isRegister = !isRegister;
            toggleBtn.innerText = isRegister ? 'Log In Instead' : 'Sign Up';
            submitBtn.innerHTML = isRegister ? '<span class="tracking-widest text-xs">CREATE ACCOUNT</span>' : '<span class="tracking-widest text-xs">SIGN IN</span>';
        });
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            try {
                const res = await fetch(isRegister ? '/api/auth/register' : '/api/auth/login', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password })
                });
                if (res.ok) window.location.href = '/dashboard';
                else CustomSwal.fire('Error', (await res.json()).error, 'error');
            } catch (err) { CustomSwal.fire('Error', 'Connection failed', 'error'); }
        });
        return;
    }

    // --- DASHBOARD LOGIC ---
    const userMenu = document.getElementById('user-menu');
    if (!userMenu) return;

    let currentUser = null;
    let chartInstance = null;

    try {
        const res = await fetch('/api/user');
        if (!res.ok) throw new Error();
        currentUser = await res.json();
        const avatarUrl = currentUser.avatar ? `https://cdn.discordapp.com/avatars/${currentUser.id}/${currentUser.avatar}.png` : `https://cdn.discordapp.com/embed/avatars/${(currentUser.discriminator || 0) % 5}.png`;
        
        userMenu.innerHTML = `
            <div class="user-profile"><img src="${avatarUrl}" class="avatar"><span class="user-name">${currentUser.username} <span class="plan-badge">${currentUser.plan}</span></span></div>
            <a href="/auth/logout" class="btn btn-danger btn-sm"><i class="fa-solid fa-right-from-bracket mr-1"></i>Logout</a>
        `;
        

        if (document.getElementById('current-plan-display')) document.getElementById('current-plan-display').innerText = currentUser.plan;
        if (currentUser.watermark) document.getElementById('opt-watermark').value = currentUser.watermark;
        if (currentUser.webhook_url) document.getElementById('opt-webhook').value = currentUser.webhook_url;
        
        // Restrictions & Admin
        const isPrem = currentUser.plan === 'Premium' || currentUser.is_admin;
        if (currentUser.plan === 'Free' && !currentUser.is_admin) {
            document.getElementById('free-plan-warning').classList.remove('hidden');
            document.getElementById('obfuscate-btn').disabled = true;
            document.getElementById('obfuscate-btn').style.opacity = '0.5';
        }
        if (!isPrem) {
            document.querySelectorAll('.prem-opt').forEach(opt => { opt.disabled = true; opt.checked = false; });
            document.getElementById('premium-settings-box').classList.add('hidden');
        }
        if (currentUser.is_admin) document.getElementById('nav-admin').classList.remove('hidden');

    } catch (e) { return window.location.href = '/login.html'; }

    // Tabs
    const tabs = document.querySelectorAll('.nav-tab');
    const tabContents = document.querySelectorAll('.tab-content');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.add('hidden'));
            tab.classList.add('active');
            document.getElementById(`tab-${tab.dataset.tab}`).classList.remove('hidden');
            if (tab.dataset.tab === 'history') loadHistory();
            if (tab.dataset.tab === 'admin') loadAdminData();
        });
    });

    // Presets, Settings, & Target Selection
    document.getElementById('settings-btn')?.addEventListener('click', () => document.getElementById('settings-panel').classList.toggle('hidden'));
    
    // Strength Meter
    function updateStrength() {
        const checks = [document.getElementById('opt-anti-tamper')?.checked, document.getElementById('opt-constants')?.checked, document.getElementById('opt-minify')?.checked];
        const score = checks.filter(Boolean).length;
        const levels = [{w:'20%',t:'LOW',c:'#ef4444'},{w:'45%',t:'MEDIUM',c:'#f59e0b'},{w:'75%',t:'HIGH',c:'#22c55e'},{w:'100%',t:'MAXIMUM',c:'#3b82f6'}];
        const l = levels[score];
        document.getElementById('strength-fill').style.width = l.w;
        const st = document.getElementById('strength-text'); st.innerText = l.t; st.style.color = l.c;
    }
    ['opt-anti-tamper','opt-constants','opt-minify'].forEach(id => document.getElementById(id)?.addEventListener('change', updateStrength));
    updateStrength();

    function formatBytes(b) { if(b<1024) return b+' B'; if(b<1048576) return (b/1024).toFixed(1)+' KB'; return (b/1048576).toFixed(1)+' MB'; }

    let currentTarget = 'lua54';
    document.querySelectorAll('.target-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.target-btn').forEach(b => b.classList.remove('active'));
            e.currentTarget.classList.add('active');
            currentTarget = e.currentTarget.dataset.target;
        });
    });

    document.querySelectorAll('.preset-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
            e.currentTarget.classList.add('active');
            const type = e.currentTarget.dataset.preset;
            const isPrem = currentUser.plan === 'Premium' || currentUser.is_admin;
            
            document.getElementById('opt-minify').checked = true;
            document.getElementById('opt-constants').checked = (type !== 'minify');
            
            if (isPrem) {
                document.getElementById('opt-anti-tamper').checked = (type === 'max');
            }
            Toast.fire({ icon: 'success', title: 'Preset Applied' });
        });
    });

    document.getElementById('save-settings-btn')?.addEventListener('click', async () => {
        const watermark = document.getElementById('opt-watermark').value;
        const webhook_url = document.getElementById('opt-webhook').value;
        try {
            const res = await fetch('/api/user/settings', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({watermark, webhook_url}) });
            if (res.ok) Toast.fire({ icon: 'success', title: 'Settings Saved' });
        } catch (e) { Toast.fire({ icon: 'error', title: 'Error saving' }); }
    });

    // Code Redemption
    document.getElementById('redeem-btn')?.addEventListener('click', async () => {
        const code = document.getElementById('promo-code-input').value.trim();
        if (!code) return;
        try {
            const res = await fetch('/api/redeem-code', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code }) });
            const data = await res.json();
            if (res.ok) CustomSwal.fire('Success!', `Upgraded to ${data.plan}.`, 'success').then(() => window.location.reload());
            else CustomSwal.fire('Error', data.error, 'error');
        } catch (e) { CustomSwal.fire('Error', 'Connection failed', 'error'); }
    });

    // Monaco
    let sourceEditor, resultEditor;
    if (document.getElementById('monaco-source')) {
        require(['vs/editor/editor.main'], function() {
            monaco.editor.defineTheme('minimalTheme', { base: 'vs-dark', inherit: true, rules: [], colors: { 'editor.background': '#00000000' }});
            monaco.editor.setTheme('minimalTheme');
            sourceEditor = monaco.editor.create(document.getElementById('monaco-source'), { value: 'print("Hello World")', language: 'lua', minimap: { enabled: false }, automaticLayout: true, fontSize: 14 });
            resultEditor = monaco.editor.create(document.getElementById('monaco-result'), { value: '-- Output', language: 'lua', readOnly: true, minimap: { enabled: false }, automaticLayout: true, fontSize: 14 });
        });
    }

    // Obfuscate
    document.getElementById('obfuscate-btn')?.addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        if (btn.disabled || !sourceEditor) return;
        const source = sourceEditor.getValue().trim();
        if (!source) return CustomSwal.fire('Empty', 'Enter code.', 'warning');

        btn.disabled = true;
        const originalText = btn.innerHTML;
        btn.innerHTML = '<span class="tracking-widest text-xs btn-text"><i class="fa-solid fa-spinner fa-spin mr-1"></i> PROCESSING</span>';
        resultEditor.setValue('PROCESSING...');
        
        const options = {};
        if (document.getElementById('opt-anti-tamper')?.checked) options.antiTamper = true;
        if (document.getElementById('opt-constants')?.checked) options.constantEncryption = true;
        if (document.getElementById('opt-minify')?.checked) options.minify = true;

        const bodyPayload = { source, target: currentTarget };
        if (Object.keys(options).length > 0) bodyPayload.options = options;

        try {
            const response = await fetch('/api/obfuscate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(bodyPayload) });
            const data = await response.json();
            if (!response.ok) throw new Error(data.details ? `${data.error}: ${data.details}` : data.error);
            resultEditor.setValue(data.output || data.code || data.result || data.script);
            // Code Stats
            const origSize = new Blob([sourceEditor.getValue()]).size;
            const obfSize = new Blob([resultEditor.getValue()]).size;
            const ratio = origSize > 0 ? Math.round(((obfSize - origSize) / origSize) * 100) : 0;
            document.getElementById('stat-original').innerText = formatBytes(origSize);
            document.getElementById('stat-obfuscated').innerText = formatBytes(obfSize);
            document.getElementById('stat-ratio').innerText = (ratio > 0 ? '+' : '') + ratio + '%';
            document.getElementById('stat-ratio').style.color = ratio > 0 ? '#f59e0b' : '#22c55e';
            document.getElementById('code-stats').classList.remove('hidden');
            Toast.fire({ icon: 'success', title: 'Complete' });
        } catch (error) {
            resultEditor.setValue(`-- [ERROR]\n-- ${error.message}`);
            CustomSwal.fire('Error', 'Build failed. Check output for details.', 'error');
        } finally { 
            btn.disabled = false; 
            btn.innerHTML = originalText;
        }
    });

    // History
    async function loadHistory() {
        try {
            const res = await fetch('/api/history');
            if (!res.ok) return;
            const history = await res.json();
            const body = document.getElementById('history-body');
            if (history.length === 0) {
                body.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No builds found.</td></tr>';
            } else {
                body.innerHTML = history.map(h => `<tr><td class="font-mono text-xs">${h.id.split('-')[0]}</td><td>${new Date(h.created_at).toLocaleString()}</td><td class="text-success">Success</td></tr>`).join('');
            }
        } catch (e) { console.error(e); }
    }

    // Admin
    async function loadAdminData() {
        if (!currentUser.is_admin) return;
        try {
            // Users
            const usersRes = await fetch('/api/admin/users');
            const users = await usersRes.json();
            if (!usersRes.ok) throw new Error(users.error || 'Failed to load users');

            // Update stat cards
            document.getElementById('stat-total-users').innerText = users.length;
            document.getElementById('stat-premium-users').innerText = users.filter(u => u.plan === 'Premium').length;
            document.getElementById('stat-banned-users').innerText = users.filter(u => u.is_banned).length;

            document.getElementById('admin-users-body').innerHTML = users.map(u => {
                let avatarUrl = u.avatar ? `https://cdn.discordapp.com/avatars/${u.id}/${u.avatar}.png` : `https://cdn.discordapp.com/embed/avatars/${(u.id || 0) % 6}.png`;
                let avatarHtml = `<img src="${avatarUrl}" style="width: 28px; height: 28px; border-radius: 50%; margin-right: 10px;" onerror="this.src='https://cdn.discordapp.com/embed/avatars/0.png'">`;
                
                const planColors = { Free: '#6b7280', Basic: '#22c55e', Premium: '#3b82f6' };
                let planBadge = `<span style="padding: 2px 10px; border-radius: 999px; font-size: 0.65rem; font-weight: 600; background: ${planColors[u.plan] || planColors.Free}20; color: ${planColors[u.plan] || planColors.Free}; border: 1px solid ${planColors[u.plan] || planColors.Free}40;">${u.plan}</span>`;
                
                let statusBadge = u.is_banned 
                    ? `<span style="padding: 2px 10px; border-radius: 999px; font-size: 0.65rem; background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.3);">Banned</span>`
                    : `<span style="padding: 2px 10px; border-radius: 999px; font-size: 0.65rem; background: rgba(34,197,94,0.15); color: #22c55e; border: 1px solid rgba(34,197,94,0.3);">Active</span>`;

                let actionButtons = `<button class="btn btn-danger btn-sm" onclick="toggleBan('${u.id}')" style="padding: 4px 12px; font-size: 0.65rem;"><i class="fa-solid fa-${u.is_banned ? 'unlock' : 'ban'} mr-1"></i>${u.is_banned?'Unban':'Ban'}</button>`;
                if (u.plan !== 'Free') {
                    actionButtons = `<button class="btn btn-outline btn-sm" onclick="revokePlan('${u.id}')" style="margin-right: 5px; padding: 4px 12px; font-size: 0.65rem;"><i class="fa-solid fa-arrow-rotate-left mr-1"></i>Revoke</button>` + actionButtons;
                }
                
                return `<tr><td class="font-mono text-xs" style="opacity:0.5">${String(u.id).substring(0,10)}...</td><td><div style="display:flex;align-items:center;">${avatarHtml}<span>${u.username}</span></div></td><td>${planBadge}</td><td>${statusBadge}</td><td>${actionButtons}</td></tr>`;
            }).join('');
            
            // Promos
            const promosRes = await fetch('/api/admin/promo-codes');
            const promos = await promosRes.json();
            if (!promosRes.ok) throw new Error(promos.error || 'Failed to load promos');
            document.getElementById('stat-total-codes').innerText = promos.length;

            const statusBadges = { true: '<span style="padding:2px 10px;border-radius:999px;font-size:0.65rem;background:rgba(107,114,128,0.15);color:#6b7280;border:1px solid rgba(107,114,128,0.3);">Used</span>', false: '<span style="padding:2px 10px;border-radius:999px;font-size:0.65rem;background:rgba(34,197,94,0.15);color:#22c55e;border:1px solid rgba(34,197,94,0.3);">Valid</span>' };
            document.getElementById('admin-codes-body').innerHTML = promos.length === 0 
                ? '<tr><td colspan="5" class="text-center text-muted">No promo codes yet. Generate one above.</td></tr>'
                : promos.map(p => `<tr><td><input type="checkbox" class="code-checkbox" value="${p.id}"></td><td class="font-mono text-xs">${p.code}</td><td>${p.plan}</td><td>${statusBadges[p.is_used]}</td><td><button class="btn btn-danger btn-sm" onclick="deleteCode(${p.id})" style="padding: 4px 10px; font-size: 0.65rem;"><i class="fa-solid fa-trash"></i></button></td></tr>`).join('');
            
            // Analytics
            const analyticsRes = await fetch('/api/admin/analytics');
            const analytics = await analyticsRes.json();
            if (!analyticsRes.ok) throw new Error(analytics.error || 'Failed to load analytics');
            const ctx = document.getElementById('analytics-chart').getContext('2d');
            if (chartInstance) chartInstance.destroy();
            chartInstance = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: analytics.labels,
                    datasets: [{ label: 'Obfuscations', data: analytics.data, borderColor: '#3b82f6', backgroundColor: 'rgba(59, 130, 246, 0.1)', fill: true, tension: 0.4 }]
                },
                options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' } }, x: { grid: { display: false } } } }
            });
        } catch (e) { 
            console.error(e); 
            document.getElementById('admin-users-body').innerHTML = `<tr><td colspan="5" class="text-danger">Error: ${e.message}</td></tr>`;
            document.getElementById('admin-codes-body').innerHTML = `<tr><td colspan="3" class="text-danger">Error: ${e.message}</td></tr>`;
        }
    }

    document.getElementById('admin-gen-code-btn')?.addEventListener('click', async () => {
        try {
            const res = await fetch('/api/admin/generate-promo', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ plan: document.getElementById('admin-plan-select').value }) });
            if (res.ok) { Toast.fire({ icon: 'success', title: 'Code generated' }); loadAdminData(); }
        } catch (err) {}
    });

    window.toggleBan = async (id) => { if((await fetch(`/api/admin/users/${id}/toggle-ban`, { method: 'POST' })).ok) { Toast.fire({ icon: 'warning', title: 'Status updated' }); loadAdminData(); } };
    window.revokePlan = async (id) => { if((await fetch(`/api/admin/users/${id}/revoke-plan`, { method: 'POST' })).ok) { Toast.fire({ icon: 'success', title: 'Plan revoked to Free' }); loadAdminData(); } };
    window.deleteCode = async (id) => {
        if (!(await CustomSwal.fire({ title: 'Delete this code?', icon: 'warning', showCancelButton: true, confirmButtonText: 'Delete' })).isConfirmed) return;
        if ((await fetch(`/api/admin/promo-codes/${id}`, { method: 'DELETE' })).ok) { Toast.fire({ icon: 'success', title: 'Code deleted' }); loadAdminData(); }
    };

    // Select All checkbox
    document.getElementById('select-all-codes')?.addEventListener('change', (e) => {
        document.querySelectorAll('.code-checkbox').forEach(cb => cb.checked = e.target.checked);
        document.getElementById('admin-delete-codes-btn').style.display = document.querySelectorAll('.code-checkbox:checked').length > 0 ? '' : 'none';
    });
    document.addEventListener('change', (e) => {
        if (e.target.classList.contains('code-checkbox')) {
            const checked = document.querySelectorAll('.code-checkbox:checked').length;
            document.getElementById('admin-delete-codes-btn').style.display = checked > 0 ? '' : 'none';
            document.getElementById('select-all-codes').checked = checked === document.querySelectorAll('.code-checkbox').length;
        }
    });

    // Bulk delete
    document.getElementById('admin-delete-codes-btn')?.addEventListener('click', async () => {
        const ids = [...document.querySelectorAll('.code-checkbox:checked')].map(cb => cb.value);
        if (!ids.length) return;
        if (!(await CustomSwal.fire({ title: `Delete ${ids.length} code(s)?`, icon: 'warning', showCancelButton: true, confirmButtonText: 'Delete All' })).isConfirmed) return;
        const res = await fetch('/api/admin/promo-codes/bulk-delete', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids }) });
        if (res.ok) { Toast.fire({ icon: 'success', title: `${ids.length} code(s) deleted` }); loadAdminData(); }
    });

    // Copy / Save / Upload
    document.getElementById('copy-btn')?.addEventListener('click', () => { navigator.clipboard.writeText(resultEditor?.getValue()); Toast.fire({ icon: 'success', title: 'Copied' }); });
    
    document.getElementById('file-upload')?.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            if (sourceEditor) {
                sourceEditor.setValue(ev.target.result);
                Toast.fire({ icon: 'success', title: 'File loaded' });
            }
        };
        reader.readAsText(file);
    });

    document.getElementById('download-btn')?.addEventListener('click', () => {
        const content = resultEditor?.getValue();
        if (!content || content.includes('PROCESSING...')) return;
        const blob = new Blob([content], { type: 'text/plain' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = `obfuscated_${Date.now()}.lua`;
        a.click();
    });
});
