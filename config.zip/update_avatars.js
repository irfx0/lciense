const Database = require('better-sqlite3');
const db = new Database('database.sqlite');

const DISCORD_BOT_TOKEN = 'MTUzNTM2Mzk3NTg3MTczMzg5MQ.GkO1U8.reI5ouFWtvSz5Ebil5lJwFgX41rFNEGllEXr7k';

async function updateAvatars() {
    console.log('🔄 Starting avatar update process...');
    
    // Get all users who have numeric IDs (Discord users) and missing avatars
    const users = db.prepare("SELECT id FROM users WHERE avatar IS NULL").all();
    
    let updatedCount = 0;

    for (const user of users) {
        // Skip non-discord users (e.g. usernames with letters or too short)
        if (!/^\d{17,20}$/.test(user.id)) continue;

        try {
            const res = await fetch(`https://discord.com/api/v10/users/${user.id}`, {
                headers: {
                    'Authorization': `Bot ${DISCORD_BOT_TOKEN}`
                }
            });

            if (res.ok) {
                const data = await res.json();
                if (data.avatar) {
                    db.prepare('UPDATE users SET avatar = ? WHERE id = ?').run(data.avatar, user.id);
                    console.log(`✅ Updated avatar for user ID: ${user.id}`);
                    updatedCount++;
                } else {
                    console.log(`⚠️ User ID: ${user.id} has no custom avatar on Discord.`);
                }
            } else {
                console.log(`❌ Failed to fetch user ID: ${user.id} (Status: ${res.status})`);
            }
            
            // Wait 1 second to avoid Discord API rate limits
            await new Promise(resolve => setTimeout(resolve, 1000));
        } catch (err) {
            console.error(`Error updating user ${user.id}:`, err.message);
        }
    }

    console.log(`🎉 Finished! Successfully updated ${updatedCount} avatars.`);
}

updateAvatars();
